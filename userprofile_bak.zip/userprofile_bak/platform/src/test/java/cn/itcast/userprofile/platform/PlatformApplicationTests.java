package cn.itcast.userprofile.platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlatformApplicationTests {

    @Test
    void contextLoads() {
    }

}
